from flask import *  
app = Flask(__name__)  
  
@app.route('/')
def getpage():
    return render_template('login.html')


@app.route('/login',methods = ['GET'])  
def login():  
      uname=request.args.get('uname')  
      passwrd=request.args.get('pass')  
      if uname=="user" and passwrd=="password":  
          return "Welcome %s" %uname  
   
   
if __name__ == '__main__':  
   app.run(debug = True) 