from flask import *  
app = Flask(__name__)  
  
@app.route('/')
def getpage():
    return render_template('login.html')


@app.route('/login',methods = ['POST'])  
def login():  
      uname=request.form['uname']  
      passwrd=request.form['pass']  
      if uname=="user" and passwrd=="password":  
          return "Welcome %s" %uname  
   
if __name__ == '__main__':  
   app.run(debug = True) 